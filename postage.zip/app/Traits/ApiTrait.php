<?php


namespace App\Traits;


trait ApiTrait {

    public function dawd() {
        // .....
    }
}
