<?php if($errors->any()): ?>
    <div class="col-md-12 d-flex flex-wrap justify-content-center align-items-center">
        <div class="alert alert-danger col-md-12" role="alert">
            <h4 class="alert-heading h5">لطفا موارد زیر را برسی کنید.</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($key+1); ?> . <?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\projects\postage\resources\views/layouts/notifications.blade.php ENDPATH**/ ?>