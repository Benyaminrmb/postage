
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <?php if(Breadcrumbs::has()): ?>
            <?php $__currentLoopData = Breadcrumbs::current(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($crumbs->url() && !$loop->last): ?>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e($crumbs->url()); ?>">
                            <?php echo e($crumbs->title()); ?>

                        </a>
                    </li>
                <?php else: ?>
                    <li class="breadcrumb-item active">
                        <?php echo e($crumbs->title()); ?>

                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
</nav>
<?php /**PATH D:\projects\postage\resources\views/admin/layouts/breadcrumb.blade.php ENDPATH**/ ?>