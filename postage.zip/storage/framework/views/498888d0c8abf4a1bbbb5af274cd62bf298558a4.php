<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('profile.index')); ?>" class="brand-link">
        <img src="https://eu.ui-avatars.com/api/?background=random&name=<?php echo e(str_replace(' ','-',Auth::user()->name)); ?>"
             alt="<?php echo e(Auth::user()->name); ?>" class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span class="brand-text font-weight-light">پیشخوان</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar" style="direction: ltr">
        <div style="direction: rtl">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <img
                        src="https://eu.ui-avatars.com/api/?background=random&name=<?php echo e(str_replace(' ','-',Auth::user()->name)); ?>"
                        class="img-circle elevation-2"
                        alt="<?php echo e(Auth::user()->name); ?>">
                </div>
                <div class="info">
                    <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <?php if(Auth::user()->userType==='agency'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.index')); ?>"
                               class="nav-link <?php echo e(request()->routeIs('admin.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fad fa-star-shooting"></i>
                                <p>
                                    داشبورد
                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('panel.index')); ?>"
                           class="nav-link <?php echo e(request()->routeIs('panel.index') ? 'active' : ''); ?>">
                            <i class="nav-icon fad fa-meteor"></i>
                            <p>
                                پیشخوان
                            </p>
                        </a>
                    </li>
                    <li class="nav-item has-treeview">
                        <a class="nav-link <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>

                        <?php echo e(request()->routeIs('profile.agency.edit.state') ? 'active' : ''); ?>

                        <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>

                        <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                            <i class="nav-icon fad fa-id-badge"></i>
                            <p>
                                پروفایل
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.index')); ?>"
                                   class="nav-link <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                                    <i class="nav-icon fad fa-id-badge"></i>
                                    <p>مشاهده پروفایل</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.edit')); ?>"
                                   class="nav-link <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                                    <i class="nav-icon fad fa-user-edit"></i>
                                    <p>ویرایش پروفایل</p>
                                </a>
                            </li>
                            <?php if(Auth::user()->userType==='agency'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('profile.agency.edit.state')); ?>"
                                       class="nav-link <?php echo e(request()->routeIs('profile.agency.edit.state') ? 'active' : ''); ?>">
                                        <i class="nav-icon fad fa-globe-asia"></i>
                                        <p> شهر نمایندگی</p>
                                        <?php if(!json_decode(Auth::user()->agencyInfo)): ?>
                                            <span class="right badge badge-danger">پیش نیاز</span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    <?php if(Auth::user()->userType==='agency'): ?>
                        <li class="nav-item has-treeview ">
                            <a class="nav-link">
                                <i class="nav-icon fad fa-clipboard-list"></i>
                                <p>
                                    سفارشات
                                    <i class="right fa fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.shipments.new.options')); ?>"
                                       class="nav-link <?php echo e(request()->routeIs('admin.shipments.new.options') ? 'active' : ''); ?>">
                                        <i class="fad fa-th-list"></i>
                                        <p>گذینه مورد نیاز مرسوله</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.shipments.list')); ?>"
                                       class="nav-link <?php echo e(request()->routeIs('admin.shipments.list') ? 'active' : ''); ?>">
                                        <i class="fad fa-th-list"></i>
                                        <p>لیست سفارشات</p>
                                    </a>
                                </li>

                            </ul>
                        </li>
                    <?php endif; ?>

                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\projects\postage\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>