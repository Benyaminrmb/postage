<ul class="navbar-nav">
    <li class="nav-item ">

        <div class="btn-group btn-group-toggle btn-group-sm btnStepStatusGroup" data-toggle="buttons">
            <?php if($shipment->accessResponse === 'granted'): ?>
                <label class="btn btn-sm font-13 <?php echo e($btnClass); ?> <?php echo e($accessResponse); ?>"
                       onclick="changeStepStatus($(this))">
                    <input type="radio" name="notApproved"
                           value="notApproved"
                           data-shipment-id="<?php echo e($shipment->id); ?>"
                           data-route="<?php echo e(route('admin.shipment.editStepStatus')); ?>"
                           <?php if($stepStatus === 'notApproved'): ?>
                           checked
                           <?php endif; ?>
                           id="option1" autocomplete="off">
                    <span class="detail"></span>
                    تایید نشده
                </label>
                <label class="btn btn-sm font-13 <?php echo e($btnClass); ?> <?php echo e($accessResponse); ?>"
                       onclick="changeStepStatus($(this))">
                    <input type="radio" name="onProcess"
                           value="onProcess"
                           data-shipment-id="<?php echo e($shipment->id); ?>"
                           data-route="<?php echo e(route('admin.shipment.editStepStatus')); ?>"
                           <?php if($stepStatus === 'onProcess'): ?>
                           checked
                           <?php endif; ?>
                           id="option1" autocomplete="off">
                    <span class="detail"></span>
                    در حال پردازش
                </label>
                <label class="btn btn-sm font-13 <?php echo e($btnClass); ?> <?php echo e($accessResponse); ?>"
                       onclick="changeStepStatus($(this))">
                    <input type="radio" name="getProduct"
                           value="getProduct"
                           data-shipment-id="<?php echo e($shipment->id); ?>"
                           data-route="<?php echo e(route('admin.shipment.editStepStatus')); ?>"
                           <?php if($stepStatus === 'getProduct'): ?>
                           checked
                           <?php endif; ?>
                           id="option1" autocomplete="off">
                    <span class="detail"></span>
                    گرفتن مرسوله
                </label>
                <label class="btn btn-sm font-13 <?php echo e($btnClass); ?> <?php echo e($accessResponse); ?>"
                       onclick="changeStepStatus($(this))">
                    <input type="radio" name="onTheWay"
                           value="onTheWay"
                           data-shipment-id="<?php echo e($shipment->id); ?>"
                           data-route="<?php echo e(route('admin.shipment.editStepStatus')); ?>"
                           <?php if($stepStatus === 'onTheWay'): ?>
                           checked
                           <?php endif; ?>
                           id="option1" autocomplete="off">
                    <span class="detail"></span>
                    در مسیر
                </label>
                <label class="btn btn-sm font-13 <?php echo e($btnClass); ?> <?php echo e($accessResponse); ?>"
                       onclick="changeStepStatus($(this))">
                    <input type="radio" name="receivedByTheRecipient"
                           value="receivedByTheRecipient"
                           data-shipment-id="<?php echo e($shipment->id); ?>"
                           data-route="<?php echo e(route('admin.shipment.editStepStatus')); ?>"
                           <?php if($stepStatus === 'receivedByTheRecipient'): ?>
                           checked
                           <?php endif; ?>
                           id="option1" autocomplete="off">
                    <span class="detail"></span>
                    تحویل داده شد
                </label>
            <?php else: ?>
                <span class="text-danger">دسترسی ندارید</span>
            <?php endif; ?>

        </div>
    </li>
</ul>
<?php /**PATH D:\projects\postage\resources\views/components/step-status.blade.php ENDPATH**/ ?>