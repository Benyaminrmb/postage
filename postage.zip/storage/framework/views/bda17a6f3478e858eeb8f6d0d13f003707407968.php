<?php $__env->startComponent('admin.layouts.content' , ['title' => 'پیشخوان']); ?>


    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="menu_img">
                <a href="<?php echo e(route('shipment.new')); ?>">
                    <img src="/img/menu1.jpg" alt="">
                </a>
            </div>

        </div>
    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\projects\postage\resources\views/profile/panel.blade.php ENDPATH**/ ?>