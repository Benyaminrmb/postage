<?php $__env->startComponent('admin.layouts.content' , ['title' => 'لیست سفارشات']); ?>


    <div class="row">
        <div class="col-12 d-flex flex-wrap">

            <div class="col-md-12 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-compass <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">وضعیت</span>
                        <div class="justify-content-center align-content-center">
                            <?php if (isset($component)) { $__componentOriginalcf43799d6ee6c0d006fb259c989df2f21ada3036 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StepStatus::class, ['shipmentId' => ''.e($shipment->id).'']); ?>
<?php $component->withName('step-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'max-w-2xl']); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf43799d6ee6c0d006fb259c989df2f21ada3036)): ?>
<?php $component = $__componentOriginalcf43799d6ee6c0d006fb259c989df2f21ada3036; ?>
<?php unset($__componentOriginalcf43799d6ee6c0d006fb259c989df2f21ada3036); ?>
<?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-shield-check <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">دسترسی شما</span>
                        <span
                            class="info-box-number mt-2  <?php echo e(AdminShipmentController::AccessTypeFaName($shipment->accessResponse,$shipment->ordered_at)['class']); ?>">
                            <?php echo e(AdminShipmentController::AccessTypeFaName($shipment->accessResponse,$shipment->ordered_at)['title']); ?>

                        </span>
                    </div>
                </div>
            </div>


            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-fingerprint <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">کد</span>
                        <span class="info-box-number mt-2 ">
                            <?php echo e($shipment->id); ?>

                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-cart-arrow-down <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">نوع تحویل</span>
                        <span class="info-box-number mt-2 ">
                            <?php echo e(AdminShipmentController::deliveryTypeFaName($shipment->deliveryType)); ?>

                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-flux-capacitor <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">روش حمل</span>
                        <span class="info-box-number mt-2 ">
                           <?php echo e(AdminShipmentController::deliveryVehicleFaName($shipment->deliveryVehicle)); ?>

                        </span>
                    </div>
                </div>
            </div>


            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-calendar-alt <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">تاریخ درخواست</span>
                        <span class="info-box-number mt-2 ">
                            <?php echo e(verta($shipment->created_at->timestamp)->format('Y/n/j')); ?>

                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-clock <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">ساعت درخواست</span>
                        <span class="info-box-number mt-2 ">
                            <?php echo e(verta($shipment->created_at->timestamp)->format('H:i')); ?>

                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-calendar-alt <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">زمان درخواست نمایندگی</span>
                        <span class="info-box-number mt-2 ">
                            <?php if($shipment->ordered_at !== null): ?>
                                <?php echo e(verta($shipment->ordered_at)->format('H:i -  Y/n/j')); ?>

                            <?php else: ?>
                                هنوز درخواست نداده اید
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                    <span class="info-box-icon bg-light">
                        <span class="fad fa-calendar-alt <?php if($isGranted): ?> text-info <?php endif; ?>"></span>
                    </span>

                    <div class="info-box-content">
                        <span class="info-box-text">زمان تایید نمایندگی</span>
                        <span class="info-box-number mt-2 ">
                            <?php if($shipment->response_at !== null): ?>
                                <?php echo e(verta($shipment->response_at)->format('H:i -  Y/n/j')); ?>

                            <?php else: ?>
                                هنوز تایید نشده
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>


        </div>

        <?php if($isGranted): ?>
            <div class="col-12 d-flex flex-wrap">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="card card-widget">
                        <div class="card-header">
                            <div class="user-block">


                                <span class="username">توضیحات ادمین</span>
                                <span
                                    class="description"><?php echo e(verta($shipment->response_at)->formatDifference()); ?></span>
                            </div>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body" style="display: block;">
                            متن توضیحات ...
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card card-light">
                        <div class="card-header">
                            <h3 class="card-title">مشخصات درخواست کننده</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body ship_div p-0">
                            <ul>
                                <li class="text-right pr-2" title="نام">نام :</li>
                                <li class="text-left pl-2" title="نام">
                                    <?php echo e($shipment->user->name); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="نام خانوادگی">نام خانوادگی :</li>
                                <li class="text-left pl-2" title="نام خانوادگی">
                                    <?php echo e($shipment->user->family); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="کد ملی">کد ملی :</li>
                                <li class="text-left pl-2" title="کد ملی">
                                    <?php echo e($shipment->user->nationalCode); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="جنسیت">جنسیت :</li>
                                <li class="text-left pl-2" title="جنسیت">
                                    <?php echo e($shipment->user->gender); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="شماره همراه">شماره همراه :</li>
                                <li class="text-left pl-2" title="شماره همراه">
                                    <a href="tel:<?php echo e($shipment->user->mobile); ?>"><?php echo e($shipment->user->mobile); ?></a>
                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="شماره ثابت">شماره ثابت :</li>
                                <li class="text-left pl-2" title="شماره ثابت">
                                    <a href="tel:<?php echo e($shipment->user->telephone); ?>"><?php echo e($shipment->user->telephone); ?></a>
                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="ایمیل">ایمیل :</li>
                                <li class="text-left pl-2" title="ایمیل">
                                    <a href="mailto:<?php echo e($shipment->user->email); ?>"><?php echo e($shipment->user->email); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card card-light">
                        <div class="card-header">
                            <h3 class="card-title">مشخصات تحویل گیرنده</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body ship_div p-0">
                            <ul>
                                <li class="text-right pr-2" title="نام">نام :</li>
                                <li class="text-left pl-2" title="نام">
                                    <?php echo e($shipmentReceiverInformation['name']); ?>


                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="نام خانوادگی">نام خانوادگی :</li>
                                <li class="text-left pl-2" title="نام خانوادگی">
                                    <?php echo e($shipmentReceiverInformation['family']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="کد ملی">کد ملی :</li>
                                <li class="text-left pl-2" title="کد ملی">
                                    <?php echo e($shipmentReceiverInformation['nationalCode']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="شماره همراه">شماره همراه :</li>
                                <li class="text-left pl-2" title="شماره همراه">
                                    <a href="tel:<?php echo e($shipmentReceiverInformation['mobile']); ?>"><?php echo e($shipmentReceiverInformation['mobile']); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="card card-light card-outline">
                        <div class="card-header">
                            <h3 class="card-title">آدرس مبداء</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body ship_div p-0">
                            <ul>
                                <li class="text-right pr-2" title="آدرس مبداء">آدرس مبداء :</li>
                                <li class="text-left pl-2" title="آدرس مبداء">
                                    <?php echo e($shipmentOriginAddress['string']); ?>


                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="استان">استان :</li>
                                <li class="text-left pl-2" title="استان">
                                    <?php echo e($shipmentOriginAddress['stateTitle']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="شهر">شهر :</li>
                                <li class="text-left pl-2" title="شهر">
                                    <?php echo e($shipmentOriginAddress['cityTitle']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-left pl-2 pr-2">
                                    <div id="map2"></div>
                                    <input type="hidden"
                                           id="originLongAddress"
                                           value="<?php echo e($shipmentOriginAddress['onMap']['long']); ?>">
                                    <input type="hidden"
                                           id="originLatAddress"
                                           value="<?php echo e($shipmentOriginAddress['onMap']['lat']); ?>">
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card card-light card-outline">
                        <div class="card-header">
                            <h3 class="card-title">آدرس مقصد</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body ship_div p-0">
                            <ul>
                                <li class="text-right pr-2" title="آدرس مبداء">آدرس مبداء :</li>
                                <li class="text-left pl-2" title="آدرس مبداء">
                                    <?php echo e($shipmentDestinationAddress['string']); ?>


                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="استان">استان :</li>
                                <li class="text-left pl-2" title="استان">
                                    <?php echo e($shipmentDestinationAddress['stateTitle']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-right pr-2" title="شهر">شهر :</li>
                                <li class="text-left pl-2" title="شهر">
                                    <?php echo e($shipmentDestinationAddress['cityTitle']); ?>

                                </li>
                            </ul>
                            <ul>
                                <li class="text-left pl-2 pr-2">
                                    <div id="map"></div>
                                    <input type="hidden"
                                           id="destinationLongAddress"
                                           value="<?php echo e($shipmentDestinationAddress['onMap']['long']); ?>">
                                    <input type="hidden"
                                           id="destinationLatAddress"
                                           value="<?php echo e($shipmentDestinationAddress['onMap']['lat']); ?>">
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>






    <script>
        var markers = [];
        var markers2 = [];
        var map;

        window.onload = function what() {
            var originLongAddress = document.getElementById('originLongAddress');
            var originLatAddress = document.getElementById('originLatAddress');
            var destinationLongAddress = document.getElementById('destinationLongAddress');
            var destinationLatAddress = document.getElementById('destinationLatAddress');
        }

        function initMap() {
            var labelIndex = 0;

            function initialize() {
                var center = {lat: Number(originLatAddress.value), lng: Number(originLongAddress.value)};
                var center2 = {lat: Number(destinationLatAddress.value), lng: Number(destinationLongAddress.value)};
                console.log(center);
                console.log(center2);
                var map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 16,
                    center: center,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });
                var map2 = new google.maps.Map(document.getElementById('map2'), {
                    zoom: 16,
                    center: center2,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var myMarker = new google.maps.Marker({
                    position: new google.maps.LatLng(Number(originLatAddress.value), Number(originLongAddress.value)),
                    draggable: true
                });

                google.maps.event.addListener(map, 'click', function (event) {
                    var lanlat_new = {
                        lat: parseFloat(event.latLng.lat().toFixed(3)),
                        lng: parseFloat(event.latLng.lng().toFixed(3))
                    };
                    addMarker(event.latLng, map);


                    originLongAddress.value = Number(lanlat_new.lng);
                    originLatAddress.value = Number(lanlat_new.lat);
                });
                google.maps.event.addListener(map2, 'click', function (event) {
                    var lanlat_new = {
                        lat: parseFloat(event.latLng.lat().toFixed(3)),
                        lng: parseFloat(event.latLng.lng().toFixed(3))
                    };
                    addMarker2(event.latLng, map2);
                    destinationLongAddress.value = Number(lanlat_new.lng);
                    destinationLatAddress.value = Number(lanlat_new.lat);
                });
                addMarker(center, map);
                addMarker2(center2, map2);
            }

            function addMarker2(location, map2) {
                clearMarkers2();
                var marker2 = new google.maps.Marker({
                    position: location,
                    map: map2,
                });
                markers2.push(marker2);
            }

            function addMarker(location, map) {
                clearMarkers();
                var marker = new google.maps.Marker({
                    position: location,
                    map: map,
                });
                markers.push(marker);
            }

            function setMapOnAll(map) {
                for (var i = 0; i < markers.length; i++) {
                    markers[i].setMap(map);
                }
            }

            function setMapOnAll2(map) {
                for (var i = 0; i < markers2.length; i++) {
                    markers2[i].setMap(map);
                }
            }

            function deleteMarkers() {
                clearMarkers();
                markers = [];
            }

            function clearMarkers() {
                setMapOnAll(null);
            }

            function clearMarkers2() {
                setMapOnAll2(null);
            }

            google.maps.event.addDomListener(window, 'load', initialize);
        }

    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBUcxNAzDyoiTXUXpLwd1a-3jOwkQpDUs&callback=initMap"
            async defer></script>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\projects\postage\resources\views/admin/shipment/detail.blade.php ENDPATH**/ ?>