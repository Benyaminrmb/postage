<nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('home')); ?>" class="nav-link">خانه</a>
        </li>

    </ul>

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3">
        <div class="input-group input-group-sm">
            <input disabled class="form-control form-control-navbar" type="search" placeholder="جستجو"
                   aria-label="Search">
            <div class="input-group-append">
                <button disabled class="btn btn-navbar" type="submit">
                    <i class="fad fa-search"></i>
                </button>
            </div>
        </div>
    </form>

    <!-- Right navbar links -->
    <?php if(Auth::user()->userType==='agency'): ?>
        <ul class="navbar-nav mr-auto">
            <!-- Messages Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="fad fa-inbox"></i>
                    <?php if($notApprovedAgencyShipments): ?>

                        <span class="badge badge-danger navbar-badge"><?php echo e(count($notApprovedAgencyShipments)); ?></span>

                    <?php endif; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-left">
                    <?php if($notApprovedAgencyShipments): ?>
                        <?php $__currentLoopData = $notApprovedAgencyShipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notApprovedAgencyShipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('admin.shipment.detail',$notApprovedAgencyShipment->id)); ?>"
                               class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img
                                        src="https://eu.ui-avatars.com/api/?background=random&name=<?php echo e(str_replace(' ','-',$notApprovedAgencyShipment->user->name)); ?>"
                                        alt="User Avatar"
                                        class="img-size-50 ml-3 img-circle">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            <?php echo e($notApprovedAgencyShipment->user->name); ?>

                                            <span class="float-left text-sm text-danger"><i
                                                    class="fa fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">
                                            <?php if($notApprovedAgencyShipment->accessResponse === 'granted'): ?>
                                                <span class="text-success">تایید شده</span>
                                            <?php else: ?>
                                                <span class="text-warning">در انتظار تایید...</span>
                                            <?php endif; ?>
                                        </p>
                                        <p class="text-sm text-muted">
                                            <i class="fa fa-clock-o mr-1"></i>
                                            <?php if($notApprovedAgencyShipment->accessResponse === 'granted'): ?>
                                                <span class="font-13">
                                            <?php echo e(verta($notApprovedAgencyShipment->response_at)->formatDifference()); ?>

                                        </span>
                                            <?php else: ?>
                                                <span class="font-13">
                                            <?php echo e(verta($notApprovedAgencyShipment->ordered_at)->formatDifference()); ?>

                                        </span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.shipments.list','not-approved')); ?>" class="dropdown-item dropdown-footer">مشاهده
                        همه پیام‌ها</a>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-comment-alt-minus"></i>
                    <?php if($lastUnseenAgencyShipments): ?>
                        <span class="badge badge-warning navbar-badge"><?php echo e(count($lastUnseenAgencyShipments)); ?></span>
                    <?php endif; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-left">
                    <?php if($lastUnseenAgencyShipments): ?>
                        <span
                            class="dropdown-item dropdown-header"><?php echo e(count($lastUnseenAgencyShipments)); ?> درخواست جدید </span>
                        <?php $__currentLoopData = $lastUnseenAgencyShipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastUnseenAgencyShipments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('admin.shipment.detail',$lastUnseenAgencyShipments->id)); ?>"
                               class="dropdown-item font-13">
                                <i class="far fa-exclamation-square ml-2"></i>
                                <span class="font-13">
                             درخواست جدید
                        </span>
                                <span class="float-left text-muted text-sm font-13">
                            <?php echo e(verta($lastUnseenAgencyShipments->created_at->timestamp)->formatDifference()); ?>

                        </span>
                            </a>
                            <div class="dropdown-divider"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.shipments.list')); ?>" class="dropdown-item dropdown-footer">نمایش همه</a>
                </div>
            </li>
        </ul>
    <?php endif; ?>
</nav>
<?php /**PATH D:\projects\postage\resources\views/admin/layouts/navbar.blade.php ENDPATH**/ ?>